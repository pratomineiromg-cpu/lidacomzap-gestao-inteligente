export type DataSourceMode = 'MOCK' | 'FIRESTORE_READONLY' | 'FIRESTORE';

export function parseDataSourceMode(value: string | undefined): DataSourceMode {
  if (!value || value.trim() === '') {
    return 'MOCK';
  }
  const normalized = value.trim();
  if (normalized === 'MOCK') return 'MOCK';
  if (normalized === 'FIRESTORE_READONLY') return 'FIRESTORE_READONLY';
  if (normalized === 'FIRESTORE') return 'FIRESTORE';
  throw new Error(`Invalid DATA_SOURCE_MODE: "${value}". Expected MOCK, FIRESTORE_READONLY, or FIRESTORE.`);
}

export function getDataSourceMode(): DataSourceMode {
  const raw = typeof import.meta !== 'undefined' && (import.meta as any).env ? (import.meta as any).env.VITE_DATA_SOURCE_MODE : undefined;
  return parseDataSourceMode(raw);
}

export function isReadOnlyMode(): boolean {
  return getDataSourceMode() === 'FIRESTORE_READONLY';
}
